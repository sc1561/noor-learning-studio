(()=>{'use strict';const norm=s=>String(s??'').normalize('NFKC').replace(/[\u064b-\u065f\u0670\u200e\u200f\u0640]/g,'').replace(/[أإآ]/g,'ا').replace(/\s+/g,' ').trim();const visible=e=>!!(e&&e.getClientRects().length);const pause=ms=>new Promise(r=>setTimeout(r,ms));let owned=false;
async function wait(fn,message,time=20000){const start=Date.now();while(Date.now()-start<time){const found=fn();if(found)return found;await pause(150);}throw Error(message);}
const page=()=>window.wrappedJSObject;
function treeName(a){const clone=a.cloneNode(true);for(const badge of clone.querySelectorAll('.label,.badge,[class*=label-],[class*=badge-]'))badge.remove();return norm(clone.textContent).replace(/^(?:درس|وحدة|فصل|كتاب)\s*/,'').replace(/\s*(?:درس|وحدة|فصل|كتاب)$/,'').trim();}
const get=(text,scope=document)=>Array.from(scope.querySelectorAll('[role="tree"] a,.jstree a')).find(a=>visible(a)&&treeName(a)===norm(text));
function check(e,on){if(!e)return;if(e.checked!==on)e.click();if(e.checked!==on)throw Error('لم يثبت خيار النموذج');}
function trigger(e){e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}));const jq=page().jQuery;if(jq){jq(e).trigger('change');jq(e).trigger('chosen:updated');}}
function options(id,labels){const e=document.getElementById(id);if(!e)return false;const found=labels.map(n=>Array.from(e.options).find(o=>norm(o.text)===norm(n))).filter(Boolean);if(!found.length)return false;for(const o of e.options)o.selected=found.includes(o);trigger(e);return found.every(o=>o.selected);}
function text(html){const d=new DOMParser().parseFromString(html,'text/html');return norm(d.body.textContent).replace(/\s/g,'');}
async function editor(id,html){if(typeof html!=='string'||/<(?:script|iframe|object|embed|form|input|button|style|svg|math|link|meta)\b|\son[a-z]+\s*=|(?:href|src|action)\s*=|javascript\s*:|url\s*\(|@import/i.test(html))throw Error('محتوى محرر غير آمن');const instance=await wait(()=>page().CKEDITOR?.instances?.[id],'محرر غير جاهز: '+id);instance.setData(html);await wait(()=>text(instance.getData())===text(html),'لم يكتمل محتوى الحقل: '+id);instance.updateElement();}
async function prepare(p){
 if(!document.querySelector('#PreparationShowInWeeklyStudyPlan'))throw Error('افتح نموذج إضافة تحضير');const title=document.querySelector('input[placeholder="العنوان"]');if(title?.value&&!owned)throw Error('يوجد تحضير في النموذج؛ افتح نموذجًا فارغًا أولًا');
 const names={5:'خامس',6:'سادس',7:'سابع',8:'ثامن',9:'تاسع'};const expected=norm(p.subject+' صف '+(names[p.grade]||p.grade));const root=await wait(()=>Array.from(document.querySelectorAll('a')).find(a=>norm(a.textContent).includes('عرض الشجرة')&&norm(a.textContent).includes(expected)),'لا تطابق المادة المفتوحة صف '+p.grade+'؛ افتح مادة المنهج الصحيح');owned=true;
 const semester=p.semester===1?'الأول':'الثاني';if(!get(semester))root.click();const term=await wait(()=>get(semester),'لم يظهر الفصل الدراسي');if(!get(p.unit_name))term.click();let unit=await wait(()=>get(p.unit_name),'لم تظهر الوحدة: '+p.unit_name);
 const findLesson=()=>{unit=get(p.unit_name)||unit;const branch=unit.closest('li');return branch&&Array.from(branch.querySelectorAll('a')).find(a=>visible(a)&&treeName(a)===norm(p.lesson_name));};if(!findLesson())unit.click();const lesson=await wait(findLesson,'لم يظهر الدرس في وحدته: '+p.lesson_name);lesson.click();
 await wait(()=>title&&norm(title.value)===norm(p.lesson_name),'لم يملأ نور عنوان الدرس تلقائيًا');await pause(1200);
 const boxes=await wait(()=>{const xs=Array.from(document.querySelectorAll('input[name^="Preparation[criteria]"]'));return xs.length&&xs;},'لم تظهر أهداف نور');const goalNorm=s=>norm(s).replace(/[.،]/g,'');const selected=p.guide_outcomes.map(g=>{const matches=boxes.filter(b=>goalNorm(b.parentElement.textContent)===goalNorm(g.text));return matches.find(b=>g.id&&b.value===g.id)||(matches.length===1?matches[0]:null);});let note='';
 if(p.goal_binding==='review'||selected.some(b=>!b)){note+='راجع أهداف نور وحدد أهداف هذا اللقاء يدويًا؛ لم تغير الإضافة خياراتها أو تضف هدفًا بديلًا. ';}else{for(const b of boxes)check(b,selected.includes(b));note+='تمت مطابقة أهداف اللقاء مع خيارات نور. ';}
 check(document.getElementById('global'),false);check(document.getElementById('PreparationShowInWeeklyStudyPlan'),false);
 if(!options('taxonomies',[p.lesson_project?'الإبداع':'التطبيق']))note+='اختر المستوى المناسب يدويًا. ';
 if(!options('strategies',p.lesson_project?['التعلم بالمشاريع','التعلم التعاوني','التعلم المتمايز']:['التعلم التعاوني','التعلم بالنمذجة','التعلم المتمايز','العصف الذهني']))note+='راجع الاستراتيجيات يدويًا. ';
 if(!options('teaching_aids',['الكتاب','جهاز عرض البيانات','جهاز الحاسب']))note+='راجع المصادر التعليمية يدويًا. ';
 for(const [id,html]of Object.entries(p.fields_html))await editor(id,html);
 return {ready:true,note:note+'عبئت خطة حصتين (80 دقيقة). اختر أسبوع العمل والتاريخ والشعب والحصتين، ثم راجع وفعل النشر إن أردت واحفظ من نور. لم يتم حفظ أو نشر آلي.'};
}
browser.runtime.onMessage.addListener(m=>{if(m.action==='probe')return Promise.resolve({isForm:!!document.querySelector('#PreparationShowInWeeklyStudyPlan')});if(m.action==='prepare')return prepare(m.plan);});
})();
